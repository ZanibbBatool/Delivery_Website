<?php

if (isset($_POST['Logout'])) {
    session_unset();
    session_destroy();
    header('Location:index.php');
}
require_once ('Views/manager.phtml');