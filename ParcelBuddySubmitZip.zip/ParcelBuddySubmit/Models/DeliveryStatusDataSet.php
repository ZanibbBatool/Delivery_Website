<?php
require_once ('Models/Database.php');
require_once('Models/DeliveryStatusData.php');
class DeliveryStatusDataSet
{
    protected $_dbHandle, $_dbInstance;

    public function __construct()
    {
        $this->_dbInstance = Database::getInstance();
        $this->_dbHandle = $this->_dbInstance->getdbConnection();
    }

    public function fetchAllDeliveryStatus()
    {
        $sqlQuery = 'SELECT * FROM delivery_status';

        $statement = $this->_dbHandle->prepare($sqlQuery);
        $statement->execute();

        $dataSet = [];
        while ($row = $statement->fetch()) {
            $dataSet[] = new DeliveryStatusData($row);
        }
        return $dataSet;
    }
}