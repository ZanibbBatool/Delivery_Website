<?php

class DeliveryStatusData
{

    protected $Id, $Status_code, $Status_text;

    public function __construct($dbRow) {
        $this->Id = $dbRow['Id'];
        $this->Status_code = $dbRow['Status_code'];
        $this->Status_text = $dbRow['Status_text'];
    }

    public function getID() {
        return $this->Id;
    }
    public function getStatusCode() {
        return $this->Status_code;
    }
    public function getStatusText() {
        return $this->Status_text;
    }
}