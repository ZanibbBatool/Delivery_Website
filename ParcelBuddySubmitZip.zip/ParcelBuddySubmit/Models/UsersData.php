<?php

class UsersData {

    protected $userid, $username, $password, $user_type, $rejectNo;

    public function __construct($dbRow) {
        $this->userid = $dbRow['userid'];
        $this->username = $dbRow['username'];
        $this->password = $dbRow['password'];
        $this->user_type= $dbRow['user_type'];
        $this->rejectNo= $dbRow['rejectNo'];
    }

    public function getUserID() {
        return $this->userid;
    }

    public function getUsername() {
        return $this->username;
    }

    public function getPassword() {
        return $this->password;
    }

    public function getUserType() {
        return $this->user_type;
    }
    public function getRejectNo() {
        return $this->rejectNo;
    }



}