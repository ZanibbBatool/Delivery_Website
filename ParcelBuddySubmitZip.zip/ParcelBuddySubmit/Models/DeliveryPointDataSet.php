<?php

require_once ('Models/Database.php');
require_once('Models/DeliveryPointData.php');

class DeliveryPointDataSet
{
    protected $_dbInstance;
    public $_dbHandle;

    public function __construct()
    {
        $this->_dbInstance = Database::getInstance();
        $this->_dbHandle = $this->_dbInstance->getdbConnection();
    }

    public function fetchAllDeliveryPoint()
    {
        $sqlQuery = 'SELECT * FROM delivery_point';

        $statement = $this->_dbHandle->prepare($sqlQuery);
        $statement->execute();

        $dataSet = [];
        while ($row = $statement->fetch()) {
            $dataSet[] = new DeliveryPointData($row);
        }
        return $dataSet;
    }
    public function createParcel($name, $address_1, $address_2, $postcode, $deliverer, $lat, $lng, $status, $del_photo) {
        $sqlQuery = "INSERT INTO delivery_point (name, address_1, address_2, postcode, deliverer, lat, lng, status, del_photo) VALUES (?,?,?,?,?,?,?,?,?)";
        $statement = $this->_dbHandle->prepare($sqlQuery);
        $statement->bindParam(1, $name);
        $statement->bindParam(2, $address_1);
        $statement->bindParam(3, $address_2);
        $statement->bindParam(4, $postcode);
        $statement->bindParam(5, $deliverer);
        $statement->bindParam(6, $lat);
        $statement->bindParam(7, $lng);
        $statement->bindParam(8, $status);
        $statement->bindParam(9, $del_photo);
        $statement->execute();
    }
    public function deleteParcel($id){
        $sqlQuery = "DELETE FROM delivery_point WHERE id = ?";
        $statement = $this->_dbHandle->prepare($sqlQuery);
        $statement->bindParam(1, $id);
        $statement->execute();
    }

    public function getUserParcel($loginUserID) {
        $sqlQuery = 'SELECT *
                     FROM delivery_point
                     JOIN users  ON delivery_point.deliverer = users.userid
                     WHERE users.userid = ?';

        $statement = $this->_dbHandle->prepare($sqlQuery);
        $statement->bindParam(1, $loginUserID);
        $statement->execute();

        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }
    public function changeDeliverer($delivererID, $newDelivererID){
        $sqlQuery = "UPDATE delivery_point SET deliverer = ? WHERE id = ?";
        $statement = $this->_dbHandle->prepare($sqlQuery);
        $statement->bindParam(1, $newDelivererID);
        $statement->bindParam(2, $delivererID);
        $statement->execute();
    }

    public function changeAddress($oldAddress1, $newAddress1, $oldAddress2, $newAddress2, $oldLatitude, $newLatitude, $oldLongitude, $newLongitude, $oldPostcode, $newPostcode, $oldDeliveryPhoto, $newDeliveryPhoto ){
        //some parameters are no longer needed, delete them once code runs successfully
        $sqlQuery = "UPDATE delivery_point 
                 SET address_1 = ?, 
                     address_2 = ?, 
                     lat = ?, 
                     lng = ?, 
                     postcode = ?, 
                     del_photo = ? 
                 WHERE address_1 = ?"; //changing table data in respect to address 1

        $statement = $this->_dbHandle->prepare($sqlQuery);
        $statement->bindParam(1, $newAddress1);
        $statement->bindParam(2, $newAddress2);
        $statement->bindParam(3, $newLatitude);
        $statement->bindParam(4, $newLongitude);
        $statement->bindParam(5, $newPostcode);
        $statement->bindParam(6, $newDeliveryPhoto);
        $statement->bindParam(7, $oldAddress1);

        $statement->execute();
    }
    public function cancelParcel($parcelID){
        $sqlQuery = ' DELETE FROM delivery_point WHERE id = :parcelID' ;
        $statement = $this->_dbHandle->prepare($sqlQuery);
        $statement->bindParam(':parcelID', $parcelID);
        $statement->execute();
    }
    public function searchParcel($loginUserID,$parameter){
        $sqlQuery = "SELECT * FROM delivery_point WHERE deliverer = :loginUserID 
                                AND (id = :param 
                                   OR name = :param 
                                   OR address_1 = :param
                                   OR address_2 = :param
                                   OR postcode = :param
                                   OR lat = :param
                                   OR lng = :param
                                OR status = :param)
                                ORDER BY status DESC
                                LIMIT 10";
        $statement = $this->_dbHandle->prepare($sqlQuery);
        $statement->bindParam(':param', $parameter);
        $statement->bindParam(':loginUserID', $loginUserID);
        $statement->execute();
        $results = $statement->fetchAll(PDO::FETCH_ASSOC); //fetching associative array this time

        $parcelArray = [];
        foreach ($results as $row) {
            $parcelArray[] = new DeliveryPointData($row);
        }

        return $parcelArray;
    }


}