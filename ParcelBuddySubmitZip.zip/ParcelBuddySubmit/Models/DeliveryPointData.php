<?php

class DeliveryPointData
{

    protected $id, $name, $address_1, $address_2, $postcode, $deliverer, $lat, $lng, $status, $del_photo;

    public function __construct($dbRow)
    {
        $this->id = $dbRow['id'];
        $this->name = $dbRow['name'];
        $this->address_1 = $dbRow['address_1'];
        $this->address_2 = $dbRow['address_2'];
        $this->postcode = $dbRow['postcode'];
        $this->deliverer = $dbRow['deliverer'];
        $this->lat = $dbRow['lat'];
        $this->lng = $dbRow['lng'];
        $this->status=$dbRow['status'];
        $this->del_photo = $dbRow['del_photo'];
    }
    public function getID() {
        return $this->id;
    }
    public function getName() {
        return $this->name;
    }
    public function getAddress1() {
        return $this->address_1;
    }
    public function getAddress2() {
        return $this->address_2;
    }
    public function getPostcode() {
    return $this->postcode;
}
    public function getDeliverer() {
        return $this->deliverer;
    }
    public function getLatitude() {
        return $this->lat;
    }
    public function getLongitude() {
        return $this->lng;
    }
    public function getStatus() {
        return $this->status;
    }
    public function getDelPhoto() {
        return $this->del_photo;
    }


}