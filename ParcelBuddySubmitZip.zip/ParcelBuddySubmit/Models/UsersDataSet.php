<?php

require_once ('Models/Database.php');
require_once('Models/UsersData.php');

class UsersDataSet {
    protected $_dbInstance;
    public $_dbHandle;

    public function __construct() {
        $this->_dbInstance = Database::getInstance();
        $this->_dbHandle = $this->_dbInstance->getdbConnection();
    }

    public function fetchAllUsers() {
        $sqlQuery = 'SELECT * FROM users';

        $statement = $this->_dbHandle->prepare($sqlQuery);
        $statement->execute();

        $dataSet = [];
        while ($row = $statement->fetch()) {
            $dataSet[] = new UsersData($row);
        }
        return $dataSet;
    }
    public function signUp($username, $password, $user_type) {
        //hashing the entered password for safety
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        //inserting the form values into user database
        $sqlQuery = "INSERT INTO users (username, password, user_type) VALUES (?, ?, ?)";
        $statement = $this->_dbHandle->prepare($sqlQuery);
        $statement->bindParam(1, $username);
        $statement->bindParam(2, $hashedPassword);
       $statement->bindParam(3, $user_type);
        $statement->execute();
    }
    public function verifyLogin($username, $loginPassword)
    {    //getting the password that matches our username
        $sqlQuery = "SELECT password FROM users WHERE username = ?";
        $statement = $this->_dbHandle->prepare($sqlQuery);
        $statement->bindParam(1, $username);
        $statement->execute();
         //using predefined method to verify the password user entered with the hash version
        if ($row = $statement->fetch()) {
            // If the row is not empty, retrieve the hashed password
            $hashedPassword = $row['password'];

            // Use password_verify to check the entered password against the hashed password
            return password_verify($loginPassword, $hashedPassword);
        } else {
            // Username not found in the database
            return false;
        }
    }

    public function searchUsers($parameter){
        $sqlQuery = "SELECT * FROM users WHERE userid = :param 
                       OR username = :param 
                       OR user_type = :param 
                       OR rejectNo = :param
                       ORDER BY rejectNo DESC
                        LIMIT 10";
        $statement = $this->_dbHandle->prepare($sqlQuery);
        $statement->bindParam(':param', $parameter);

        $statement->execute();
        $results = $statement->fetchAll(PDO::FETCH_ASSOC); //fetching associative array this time

        $userArray = [];
        foreach ($results as $row) {
            $userArray[] = new UsersData($row);
        }

        return $userArray;
    }
    public function increaseRejectionNo($loginUserID){
        $sqlQuery = ' UPDATE users SET rejectNo = rejectNo + 1 WHERE userid = :loginUserID;' ;
        $statement = $this->_dbHandle->prepare($sqlQuery);
        $statement->bindParam(':loginUserID', $loginUserID);
        $statement->execute();
    }
    function checkUsername($username) {
        $sqlQuery = "SELECT * FROM users WHERE username = :username";
        $statement = $this->_dbHandle->prepare($sqlQuery);
        $statement->bindParam(':username', $username);
        $statement->execute();
        $usernameCheck = $statement->fetch();
        return $usernameCheck !== false; // Returns true if the username already exists
    }
}
